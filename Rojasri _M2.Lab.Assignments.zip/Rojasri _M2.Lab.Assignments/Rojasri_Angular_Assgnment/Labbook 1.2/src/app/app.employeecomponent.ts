import {Component} from '@angular/core'

@Component({
    selector:'emp-app',
    templateUrl: `./app.employee.html`
})
export class EmployeeComponent{
    

    //part of two way binding

    empId:number;
    employeeName:string;
    employeePrice:number;
    employeeDescription;
    showAll(){
        alert(this.empId+" "
        +this.employeeName+" "
        +this.employeePrice+" "
        +this.employeeDescription+" ")
    
    }    

}