
export class Camera{
    camTypeId:number;
    camTypeName:string;
}